from tkinter import *
import tkinter.messagebox
import importlib.util

root = Tk()

root.geometry("330x220")
root.resizable(0,0)
## IP field  row = 0

Label(root, text="IP address: ").grid(row=0,column=0)

def limitSizeip(*args):
    value = ip[i].get()
    if len(value) > 2: ip[i].set(value[:3])


ip = []

for i in range(4):
	ip.append(StringVar())
	ip[i].trace('w',limitSizeip)


column = 1
for i in range(4):
	dot = Label(root,text=".")
	entry = Entry(root, textvariable=ip[i], width=3,)
	entry.grid(row=0,column=column)
	column+=1
	if i == 3:
		break
	dot.grid(row=0,column=column)
	column+=1

#IP = '.'.join(str(e.get()) for e in ip)
''''''


## port number row = 1
row = 1
port = StringVar()
Label(root, text="Port number: ").grid(row=row, column=0)
Entry(root, textvariable=port, width=5).grid(row=row, column=1,columnspan=2)


## video name row = 2
row = 2
video_name = StringVar()
Label(root, text="Video name: ").grid(row=row, column=0)
Entry(root, textvariable=video_name, width=20).grid(row=row, column=1, columnspan=10)



## mode button
row = 3
mode = -1
def button1():
	mode = 0
	button1['fg']="black"
	button2['fg']="gray"
	key_label['fg']="gray"
	key_ent['state']=DISABLED
	print(mode)
def button2():
	mode = 1
	button1['fg']="gray"
	button2['fg']="black"
	key_label['fg']="black"
	key_ent['state']=NORMAL
	print(mode)
Label(root, text="Choose mode: ").grid(row=row, column=0)
button1 = Button(root, text='Mode A', width=9, command=button1)
button2 = Button(root, text='Mode B', width=9, command=button2)

button1.grid(row=row, column=1, columnspan=3)
button2.grid(row=row, column=5, columnspan=3)
#button1.bind('<Button-1>',button1)
#button2.bind('<Button-1>',button2)

## public key if choose Mode B   row = 4
row = 4
public_key = StringVar()
key_label = Label(root, text="Public Key: ")
key_ent = Entry(root, textvariable=public_key, width=20)

key_label.grid(row=row, column=0)
key_ent.grid(row=row, column=1, columnspan=10)

## progress bar  row = 5
row = 5
Label(root, text="Progress: ").grid(row=row, column=0)

## button OK  row = 6
row = 7

def press_button():
	if mode == 0:
		spec = importlib.util.spec_from_file_location("client_process", "/Users/joe/Desktop/Video-Faker/network/clinet.py")
		foo = importlib.util.module_from_spec(spec)
		spec.loader.exec_module(foo)
		foo.get_file('.'.join(str(e.get()) for e in ip), port, video_name)
	elif mode == 1:
		spec = importlib.util.spec_from_file_location("client_process", "/Users/joe/Desktop/Video-Faker/video-processing/client_process.py")
		foo = importlib.util.module_from_spec(spec)
		spec.loader.exec_module(foo)
		foo.decry("../network/2.mp4","../shortvideo/2/cover.mp4",11)
	else:
		tkinter.messagebox.showinfo("Error", "Choose a mode")




Button(root, text='OK', width=9, command=press_button).grid(row=row, column=1, columnspan=3)
Button(root, text='View', width=9, command=root.destroy).grid(row=row, column=4, columnspan=3)






root.mainloop()