from Crypto.Cipher import AES
from socket import *
import sys
import os
from Crypto.PublicKey import RSA
# If covered file not exist , then run the following to create mp4
'''
spec = importlib.util.spec_from_file_location("server_process", "/Users/joe/Desktop/Video-Faker/video-processing/server_process.py")
foo = importlib.util.module_from_spec(spec)
spec.loader.exec_module(foo)


foo.encry("../example-videos/origin.mp4","../test_image/cover.mp4",9,0)
'''

# AES 
with open("mykey.pem",'r') as f:
	publickey = RSA.importKey(f.read())

message = "2,11,"
#publickey = "hello"


tcpSerSock = socket(AF_INET, SOCK_STREAM)
tcpSerSock.bind(('', 8786))
tcpSerSock.listen(1)
hi = {"B04201043":3, "B04201032":5}
while 1:
	print('Ready to serve...')
	tcpCliSock, addr = tcpSerSock.accept()
	print('Received a connection from:', addr)
	try:
		request_code = tcpCliSock.recv(1024).decode('utf-8')
		if request_code in ["100", "101", "102","200"]:
			print(request_code)
			tcpCliSock.send(request_code.encode())
			message = tcpCliSock.recv(1024).decode('utf-8')

			if request_code == "100":
				try:
					size = os.path.getsize("./"+message)
					size_str = str(size)
				except:
					size_str = "Video Not Exist"
				tcpCliSock.send(size_str.encode())
			elif request_code == "101":
				f = open("./"+message,'rb')
				data = f.read(1024)
				while(data):
					print("Sending")
					tcpCliSock.send(data)
					data = f.read(1024)
				print("transaction sucessful")
				tcpCliSock.shutdown(SHUT_WR)
			elif request_code == "102":
				f = open("./"+message,'rb')
				data = f.read(1024)
				while(data):
					print("Sending")
					tcpCliSock.send(data)
					data = f.read(1024)
				print("transaction sucessful")
				tcpCliSock.shutdown(SHUT_WR)
			elif request_code == "200":
				message = RSA.importKey(message, passphrase=None)
				if message == publickey:
					file_list = os.listdir('.')
					file_list = [file for file in file_list if file.endswith("encry.mp4")]
					file_list = [file+"("+str(float(os.path.getsize("./"+file))/1024/1024)[:3]+"Mb)" for file in file_list]
					file_list.sort()
					file_list = ','.join(file_list).encode()
					print(message)
					print(file_list)
					tcpCliSock.send(file_list)
					tcpCliSock.shutdown(SHUT_WR)
				else:
					print(message)
					data = "ERROR"
					tcpCliSock.send(data.encode())
					tcpCliSock.shutdown(SHUT_WR)
	except:
		pass
