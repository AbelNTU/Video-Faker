import importlib.util
from socket import *
import sys



spec = importlib.util.spec_from_file_location("client_process", "./client_process.py")
foo = importlib.util.module_from_spec(spec)
spec.loader.exec_module(foo)

foo.decry("../network/"+str(2)+"_encry.mp4","../network/cover.mp4",17)